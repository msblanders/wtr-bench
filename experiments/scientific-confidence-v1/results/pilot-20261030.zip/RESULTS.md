# Scientific confidence v1: exploratory pilot

Recorded API cost: $4.0390. Calls: 224/224.

Lower regret is better. Oracle readout is an answer-supplied diagnostic.

| Arm | Valid | Invalid / missing | Posterior regret | Future regret |
|---|---:|---:|---:|---:|
| generic_review | 32 | 0 / 0 | 0.005158 | 0.004112 |
| calibration_checklist | 32 | 0 / 0 | 0.000014 | 0.000129 |
| contrastive_audit | 30 | 2 / 0 | 0.002087 | 0.001973 |
| oracle_readout | 32 | 0 / 0 | 0.000000 | 0.000011 |

Primary paired comparison (audit minus checklist; negative favors audit):

```json
{
  "n_paired_cases": 30,
  "mean_delta": 0.0020726209895484803,
  "bootstrap_95_percentile_interval": [
    -1.3686207460287197e-05,
    0.00621173846867511
  ]
}
```

Exploratory, one model/configuration, 32 simulated cases by default. Matched call/token ceilings, not equal actual compute. No weights were trained. The supplied models are exhaustive and correctly specified; real science is not. This measures probabilistic model comparison, not general scientific reasoning. Do not select or tune a procedure on this pilot and call its result confirmation.
