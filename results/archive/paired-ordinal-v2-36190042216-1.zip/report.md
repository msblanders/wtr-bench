# paired-ordinal-v2: FAIL

Records: 240/240. Base cases: 30 (six constructed categories).
The gate concerns these final answers only; it does not authorize a social pilot.

| Category | Correct / 40 | Joint pass 1 / 10 | Joint pass 2 / 10 | C | D | Unusable/missing |
|---|---:|---:|---:|---:|---:|---:|
| discriminating | 36 | 9 | 9 | 2 | 2 | 0 |
| both_give | 28 | 4 | 4 | 28 | 0 | 2 |
| both_keep | 28 | 5 | 4 | 28 | 6 | 2 |
| ability_conflict | 40 | 10 | 10 | 0 | 0 | 0 |
| ability_equal | 40 | 10 | 10 | 40 | 0 | 0 |
| underdetermined | 21 | 4 | 3 | 3 | 21 | 0 |

See report.json for position, name and repeat comparisons with denominators.
See answer-audit.csv for every scheduled item, including missing responses.
Repeated presentations are not independent participants or fresh scenarios.
