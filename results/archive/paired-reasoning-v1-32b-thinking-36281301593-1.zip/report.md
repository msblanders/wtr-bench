# paired-reasoning-v1: 32b-thinking: COMPLETE

Qwen/Qwen3-32B; FP8; reasoning requested high; temperature 0.6; cap 32768.
Origin: deepinfra_api. Recorded 144/144 social responses.
Separate reasoning present in 144 responses.
Six scenarios, 72 distinct prompts. No scientific PASS/FAIL.

| Scenario | Probe | Unable | Unwilling | Equal | D | Invalid | Missing | Net |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| couch | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| couch | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| couch | ability_different | 2 | 0 | 1 | 5 | 0 | 0 | 0.250 |
| faucet | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| faucet | ability_same | 0 | 6 | 0 | 2 | 0 | 0 | -0.750 |
| faucet | ability_different | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| spreadsheet | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| spreadsheet | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| spreadsheet | ability_different | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| translate | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| translate | ability_same | 0 | 5 | 0 | 3 | 0 | 0 | -0.625 |
| translate | ability_different | 0 | 0 | 1 | 7 | 0 | 0 | 0.000 |
| dog | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| dog | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| dog | ability_different | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| presentation | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| presentation | ability_same | 0 | 6 | 0 | 2 | 0 | 0 | -0.750 |
| presentation | ability_different | 1 | 0 | 4 | 3 | 0 | 0 | 0.125 |

Scenarios with both predicted signs: 6/6.
Prospective descriptive category: D_lower__six_scenario_criterion_met.

| Factor | Probe | Disagreements | Comparable | Scheduled |
|---|---|---:|---:|---:|
| position | valuation | 0 | 24 | 24 |
| position | ability_same | 7 | 24 | 24 |
| position | ability_different | 11 | 24 | 24 |
| name | valuation | 0 | 24 | 24 |
| name | ability_same | 5 | 24 | 24 |
| name | ability_different | 14 | 24 | 24 |
| repeat | valuation | 0 | 24 | 24 |
| repeat | ability_same | 5 | 24 | 24 |
| repeat | ability_different | 8 | 24 | 24 |

See report.json for all 48 crossovers, cell answers, pass splits and usage.
Configuration comparison; changes in reasoning, sampling and token budget are bundled.
Repeat disagreements now include sampling variation. No answers repaired from traces.
Retain and report both extensions and the original negative result.
Earlier known-answer validation applies to Sonnet, not these models.
