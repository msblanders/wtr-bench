# paired-pilot-v1: COMPLETE

Data origin: anthropic_api. Records: 144/144. No scientific PASS/FAIL.
Six scenarios, three probes, eight presentations per cell; 72 distinct prompts.

| Scenario | Probe | Unable | Unwilling | Equal | Insufficient | Invalid | Missing | Net |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| couch | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| couch | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| couch | ability_different | 2 | 1 | 2 | 3 | 0 | 0 | 0.125 |
| faucet | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| faucet | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| faucet | ability_different | 2 | 2 | 2 | 2 | 0 | 0 | 0.000 |
| spreadsheet | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| spreadsheet | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| spreadsheet | ability_different | 4 | 0 | 4 | 0 | 0 | 0 | 0.500 |
| translate | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| translate | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| translate | ability_different | 1 | 0 | 1 | 6 | 0 | 0 | 0.125 |
| dog | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| dog | ability_same | 0 | 6 | 0 | 2 | 0 | 0 | -0.750 |
| dog | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| presentation | valuation | 8 | 0 | 0 | 0 | 0 | 0 | 1.000 |
| presentation | ability_same | 0 | 8 | 0 | 0 | 0 | 0 | -1.000 |
| presentation | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |

## Matched valuation / same-task ability responses

| Scenario | Predicted crossover / 8 | Reverse / 8 | Same person | Includes C/D | Invalid/missing | V net | Ability net |
|---|---:|---:|---:|---:|---:|---:|---:|
| couch | 8 | 0 | 0 | 0 | 0 | 1.000 | -1.000 |
| faucet | 8 | 0 | 0 | 0 | 0 | 1.000 | -1.000 |
| spreadsheet | 8 | 0 | 0 | 0 | 0 | 1.000 | -1.000 |
| translate | 8 | 0 | 0 | 0 | 0 | 1.000 | -1.000 |
| dog | 6 | 0 | 0 | 2 | 0 | 1.000 | -0.750 |
| presentation | 8 | 0 | 0 | 0 | 0 | 1.000 | -1.000 |

## Presentation sensitivity

| Factor | Disagreements | Comparable pairs | Scheduled pairs |
|---|---:|---:|---:|
| position | 11 | 72 | 72 |
| name | 14 | 72 | 72 |
| repeat | 4 | 72 | 72 |

Net = (unable selections - unwilling selections) / 8 scheduled responses.
C/D/invalid/missing add no directional count but stay separately visible.
Net is not a giving probability or WTR. An interaction-like difference alone
does not establish both predicted directions. No control correctness keys apply.
See report.json for all eight responses in each cell and all pass splits.
No explanation review is performed by this scorer. Do not rerun collection.
