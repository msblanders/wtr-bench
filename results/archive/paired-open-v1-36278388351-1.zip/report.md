# paired-open-v1: COMPLETE

Qwen/Qwen3-14B; DeepInfra; FP8; reasoning disabled. Origin: deepinfra_api.
Recorded 144/144. Six scenarios, 72 distinct prompts. No scientific PASS/FAIL.
Hosted weight revision is not independently verified.

| Scenario | Probe | Unable | Unwilling | Equal | Insufficient | Invalid | Missing | Net |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| couch | valuation | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| couch | ability_same | 0 | 2 | 0 | 6 | 0 | 0 | -0.250 |
| couch | ability_different | 0 | 0 | 1 | 7 | 0 | 0 | 0.000 |
| faucet | valuation | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| faucet | ability_same | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| faucet | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| spreadsheet | valuation | 0 | 0 | 2 | 6 | 0 | 0 | 0.000 |
| spreadsheet | ability_same | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| spreadsheet | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| translate | valuation | 2 | 0 | 0 | 6 | 0 | 0 | 0.250 |
| translate | ability_same | 4 | 0 | 0 | 4 | 0 | 0 | 0.500 |
| translate | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| dog | valuation | 0 | 4 | 0 | 4 | 0 | 0 | -0.500 |
| dog | ability_same | 0 | 2 | 0 | 6 | 0 | 0 | -0.250 |
| dog | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| presentation | valuation | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| presentation | ability_same | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |
| presentation | ability_different | 0 | 0 | 0 | 8 | 0 | 0 | 0.000 |

## Predicted directions

| Scenario | Predicted crossover / 8 | Reverse / 8 | Giving net | Ability net | Both signs |
|---|---:|---:|---:|---:|---|
| couch | 0 | 0 | 0.000 | -0.250 | False |
| faucet | 0 | 0 | 0.250 | 0.000 | False |
| spreadsheet | 0 | 0 | 0.000 | 0.250 | False |
| translate | 0 | 0 | 0.250 | 0.500 | False |
| dog | 0 | 0 | -0.500 | -0.250 | False |
| presentation | 0 | 0 | 0.000 | 0.000 | False |

## Presentation sensitivity

| Factor | Probe | Disagreements | Comparable | Scheduled |
|---|---|---:|---:|---:|
| position | valuation | 10 | 24 | 24 |
| position | ability_same | 10 | 24 | 24 |
| position | ability_different | 1 | 24 | 24 |
| name | valuation | 6 | 24 | 24 |
| name | ability_same | 10 | 24 | 24 |
| name | ability_different | 1 | 24 | 24 |
| repeat | valuation | 0 | 24 | 24 |
| repeat | ability_same | 0 | 24 | 24 |
| repeat | ability_different | 1 | 24 | 24 |

Net = (unable - unwilling) / 8 scheduled responses; not WTR or probability.
C, D, invalid and missing remain distinct. Explanations never repair answers.
See report.json for all cell answers, pass splits, crossovers and usage.
Publish both models regardless of outcome. No explanation review is automated.
The earlier known-answer validation applies to Sonnet, not to this model.
