# paired-natural-v3.2: PASS

Records: 280/280. Base cases: 35 (six gated categories, one exploratory). Distinct prompts: 132. Six categories have 20 distinct prompts shown twice; insufficient has 12 across 40 requests (eight shown twice, two four times, and two eight times).
The gate concerns the six gated categories only; it does not authorize a social pilot.

| Category | Gated | Correct or as-expected / 40 | Joint pass 1 / 10 | Joint pass 2 / 10 | C | D | A/B | Unusable/missing |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| policy_determined | yes | 40 | 10 | 10 | 0 | 0 | 40 | 0 |
| policy_equal | yes | 40 | 10 | 10 | 40 | 0 | 0 | 0 |
| insufficient | yes | 40 | 10 | 10 | 0 | 40 | 0 | 0 |
| ability_conflict | yes | 40 | 10 | 10 | 0 | 0 | 40 | 0 |
| ability_equal | yes | 40 | 10 | 10 | 40 | 0 | 0 | 0 |
| valuation_distractor | yes | 40 | 10 | 10 | 0 | 0 | 40 | 0 |
| regard_deeds | no | 40 | 10 | 10 | 0 | 0 | 40 | 0 |

See report.json for position, name and repeat comparisons with denominators.
See answer-audit.csv for every scheduled item, including missing responses.
Repeated presentations are not independent participants or fresh scenarios.
